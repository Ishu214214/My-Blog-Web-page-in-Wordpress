<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '(lvB>k73ccoe=Txa8Ta&-1(~I/HeQ=5&k h+XOXuU9RyEpV>!mwMzo[ AU;!YX*{' );
define( 'SECURE_AUTH_KEY',  'eG|E435j|tUyY+hu;A@v}*u_3sJ9xDh8D`Vv,_@-{0t9Z?3y$sDW-x9mzm6xIZSh' );
define( 'LOGGED_IN_KEY',    'C%$c?j%EFEH*_&nu4^%y$K;+4x=yMx0@QZm0w-f;l} .!f?mjMfn+Q-7c#TeB)rg' );
define( 'NONCE_KEY',        'Ck-<aN^-SXOoLHK/CHr;K%GT3F`^SbAC8t,HL:wx8O_:*&hwp+tBUN!d:9Rq{&@8' );
define( 'AUTH_SALT',        'kM!__]-^o.;UK1#.zy/Tg>I3zxxVG}c5T#9?chd<.:I91vpV/MnUAx&K@8zlk$(_' );
define( 'SECURE_AUTH_SALT', 'V%=KX=%jC>=2FV7m&.7;[?GA#H_,,Fd.b9x kognSM-+GbJ8>B&7h|Qh)-FzF9yH' );
define( 'LOGGED_IN_SALT',   'z8AWg9XJ.kF04?+[LKa|xMmn)yq&JTVb!0RI7D*fv}>v>|F1Nr?3Yl3**+LByS#:' );
define( 'NONCE_SALT',       'ey <|T@5LBhPE&/8>`RML=^@>D&~Vhu^1Q^3HyZRhH)jM!Yk`fl0{&k>(rlz.u(h' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
